import numpy as np
from sklearn.metrics import mean_squared_error
from collections import Counter
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from sklearn.metrics import normalized_mutual_info_score
import os
from numpy import sqrt

class unit:
    def __init__(self,X_hat_y_norm,Y_hat_y_norm):
        self.X_hat_y_norm=X_hat_y_norm
        self.Y_hat_y_norm=Y_hat_y_norm

    def assign_cluster_label(self,X, Y):
        kmeans = KMeans(n_clusters=len(set(Y))).fit(X)
        Y_pred = np.zeros(Y.shape)
        for i in set(kmeans.labels_):
            ind = kmeans.labels_ == i
            Y_pred[ind] = Counter(Y[ind]).most_common(1)[0][0] # assign label.
        return Y_pred
    def mf_multiplicative_update(self,R, P, Q, steps=100):
        
        # This function aims to perform Non-negative Matrix Factorization using multiplicative update rules.
        # Given a matrix 'R', it attempts to find two non-negative matrices 'P' and 'Q' such that R ≈ P*Q^T.
        simple_rmse_l = []
        simple_acc = []
        simple_nmi = []
        for step in range(steps):
            
            Pu = P * (R.dot(Q)) / (P.dot(Q.T).dot(Q) + 1e-7)
            
            # Taking the transpose of the resulting matrix gives the updated values for 'Q', which we store in 'Qu'.
            Qu = (Q.T * (Pu.T.dot(R)) / (Pu.T.dot(Pu).dot(Q.T) + 1e-7)).T
            
            # Re-assign the updated matrices to P and Q, and continue to the next iteration.
            P = Pu
            Q = Qu
            simple_rmse_l.append(sqrt(mean_squared_error(self.X_hat_y_norm, P.dot(Q.T))))
            Y_pred_simple = self.assign_cluster_label(Q, self.Y_hat_y_norm)
            simple_acc.append(accuracy_score(self.Y_hat_y_norm, Y_pred_simple))
            simple_nmi.append(normalized_mutual_info_score(self.Y_hat_y_norm, Y_pred_simple))
        return P,Q,simple_rmse_l,simple_acc,simple_nmi
    def l1_norm_nmf(self,R,P,Q,alpha = 1e-7, steps=100):
        l1_rmse = []
        l1_acc = []
        l1_nmi = []
        for step in range(steps):
            # Update P
            Pu = P * (R.dot(Q)) / (P.dot(Q.T).dot(Q) + 1e-7)
            Pu += alpha * np.sum(np.abs(Pu))

            # Update Q
            Qu = (Q.T * (Pu.T.dot(R)) / (Pu.T.dot(Pu).dot(Q.T) + 1e-7)).T
            Qu += alpha * np.sum(np.abs(Qu))

            P = Pu
            Q = Qu
            l1_rmse.append(sqrt(mean_squared_error(self.X_hat_y_norm, P.dot(Q.T))))
            Y_pred_L1 = self.assign_cluster_label(Q, self.Y_hat_y_norm)
            l1_acc.append(accuracy_score(self.Y_hat_y_norm, Y_pred_L1))
            l1_nmi.append(normalized_mutual_info_score(self.Y_hat_y_norm, Y_pred_L1))

        return P, Q,l1_rmse,l1_acc,l1_nmi
    
    def l21_multiplicative_update(self,X, U, V, steps=100,goal=1e-5):
        l21_rmse = []
        l21_acc = []
        l21_nmi = []
        P=U
        Q=V
        for step in range(steps):
            D = np.diag(1 / np.sqrt(np.sum(np.square(X - U.dot(V)), axis=0)))

            Pu = U * (X.dot(D).dot(V.T))/(U.dot(V).dot(D).dot(V.T))
            Qu = V * (Pu.T.dot(X).dot(D))/(Pu.T.dot(Pu).dot(V).dot(D))
            
            e_P = np.sqrt(np.sum((Pu-P)**2, axis=(0,1)))/P.size
            e_Q = np.sqrt(np.sum((Qu-Q)**2, axis=(0,1)))/Q.size

            if e_P<goal and e_Q<goal:
                print("step is:",step)
                break
            P = Pu
            Q = Qu
            U=Pu
            V=Qu
            l21_rmse.append(sqrt(mean_squared_error(self.X_hat_y_norm, P.dot(Q))))
            Y_pred_L21 = self.assign_cluster_label(Q.T, self.Y_hat_y_norm)
            l21_acc.append(accuracy_score(self.Y_hat_y_norm, Y_pred_L21))
            l21_nmi.append(normalized_mutual_info_score(self.Y_hat_y_norm, Y_pred_L21))
        return P, Q,l21_rmse,l21_acc,l21_nmi