import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Define a fully connected network class.
class FCNet_CIFAR (nn.Module):
    def __init__(self, transition_matrix,input_dim, hidden_dim, output_dim):
        super(FCNet_CIFAR, self).__init__()
        self.input_layer = nn.Linear(input_dim, hidden_dim)
        self.hidden_layer = nn.Linear(hidden_dim, hidden_dim)
        self.output_layer = nn.Linear(hidden_dim, output_dim)
        self.transition_matrix=transition_matrix.to(device)
    def forward(self, x):
        # TODO based on the class attributes (fields), define a fully connected network with one hidden layer.
        # Specifically, it should have this structure:
        # input_layer->relu->hidden_layer->relu->output_layer.
        out = torch.flatten(x, start_dim=1)
        out = F.relu(self.input_layer(out))
        out = F.relu(self.hidden_layer(out))
        out = self.output_layer(out)
        out = torch.matmul(self.transition_matrix, out.T).T   
        return out
def Predefined_FCNet_CIFAR (transition_matrix,input_dim=3072, hidden_dim=100, output_dim=3):
    model = FCNet_CIFAR(transition_matrix,input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim)
    return model
