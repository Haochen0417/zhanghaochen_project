import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


device = 'cuda' if torch.cuda.is_available() else 'cpu'

class CNNModel(nn.Module):
    def __init__(self, transition_matrix):
        super(CNNModel, self).__init__()

        self.model = nn.Sequential(nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=0),
                                   nn.ReLU(),
                                   nn.MaxPool2d(kernel_size=2, stride=2, padding=0),
                                   nn.Conv2d(in_channels=6, out_channels=10, kernel_size=5, stride=1, padding=0),
                                   nn.ReLU(),
                                   nn.MaxPool2d(kernel_size=2, stride=2, padding=0),
                                   nn.Flatten(start_dim=1),
                                   nn.Dropout(0.5),
                                   nn.Linear(in_features=160, out_features=22),
                                   nn.ReLU(),
                                   nn.Linear(in_features=22, out_features=3))

        self.logsoftmax = torch.nn.LogSoftmax(dim=1)


        self.transition_matrix = transition_matrix.to(device)

    def forward(self, x):
        out = self.model(x)
        out = torch.exp(self.logsoftmax(out))
        out = torch.matmul(self.transition_matrix, out.T).T
        out = torch.log(out)
        return out
def Predefined_CNN(transition_matrix):
    model = CNNModel(transition_matrix)
    return model