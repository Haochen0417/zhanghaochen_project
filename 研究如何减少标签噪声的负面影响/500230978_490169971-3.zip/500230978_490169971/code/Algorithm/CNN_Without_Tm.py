import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


class CNNModel_Without_Tm(nn.Module):
    def __init__(self):
        super(CNNModel_Without_Tm, self).__init__()

        self.model = nn.Sequential(nn.Conv2d(in_channels=3, out_channels=6, kernel_size=5, stride=1, padding=0),
                                   nn.ReLU(),
                                   nn.MaxPool2d(kernel_size=2, stride=2, padding=0),
                                   nn.Conv2d(in_channels=6, out_channels=10, kernel_size=5, stride=1, padding=0),
                                   nn.ReLU(),
                                   nn.MaxPool2d(kernel_size=2, stride=2, padding=0),
                                   nn.Flatten(start_dim=1),
                                   nn.Dropout(0.5),
                                   nn.Linear(in_features=250, out_features=27),
                                   nn.ReLU(),
                                   nn.Linear(in_features=27, out_features=3))

        self.logsoftmax = torch.nn.LogSoftmax(dim=1)



    def forward(self, x):
        out = self.model(x)
        out = torch.exp(self.logsoftmax(out))
        out = torch.log(out)
        return out

def Predefined_CNN_Without_Tm():
    return CNNModel_Without_Tm()